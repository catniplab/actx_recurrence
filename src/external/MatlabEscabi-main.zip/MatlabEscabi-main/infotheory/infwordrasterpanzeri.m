%
%function [InfoData]=infwordrasterpanzeri(RASTER,Fsd,B)
%
%   FILE NAME   : INF WORD RASTER PANZERI
%   DESCRIPTION : Noise Enthropy of a Spike Train obtained from the 
%                 rastergram by computing the 
%                 Probability Distribution, P(W|t), of finding a B
%                 letter Word, W, in the Spike Train at time T. Uses the
%                 Bias removal procedure of Panzeri. 
%
%                   Ish = H  + - Ht_ind + Ht_sh  - Ht
%
%   RASTER      : Rastergram - compressed format
%   Fsd         : Sampling rate for generating P(W)
%   B           : Length of Word, number of bits
%
%RETURNED VARIABLES
%
%   InfoData    : Data Structure containing
%
%                 .HWord       : Enthropy per Word
%                 .HWordt      : Conditional Enthropy per Word
%                 .HSec        : Enthropy per Second
%                 .HSect       : Conditional Enthropy per Second
%                 .HSpike      : Enthropy per Spike
%                 .HSpiket     : Conditional Enthropy per Spike
%
%           Panzeri shuffled - i.e., shuffle across trials
%
%                 .HWord_sh    : Enthropy per Word
%                 .HWordt_sh   : Conditional Enthropy per Word
%                 .HSec_sh     : Enthropy per Second
%                 .HSect_sh    : Conditional Enthropy per Second
%                 .HSpike_sh   : Enthropy per Spike
%                 .HSpiket_sh  : Conditional Enthropy per Spike
%
%           Independent bins
%
%                 .HWordt_sh   : Conditional Enthropy per Word
%                 .HSect_sh    : Conditional Enthropy per Second
%                 .HSpiket_sh  : Conditional Enthropy per Spike
%
%           Firing Rate
%
%                 .Rate        : Firing Rate
%
%           Parameters
%
%                 .Param.dt   - Temporal Resolution (ms)
%                 .Param.Fsd  - Rastergram sampling rate 
%                 .Param.B    - Number of bins per word
%
% (C) Monty A. Escabi, Feb 2020 - original version INFWORDRASTER
%
function [InfoData]=infwordrasterpanzeri(RASTER,Fsd,B)

%Expand RASTER - convert to matrix format
[RAS]=rasterexpand(RASTER,Fsd,RASTER(1).T);
RAS=RAS/Fsd;

%Binary Mask
D=max(max(max(RAS)),2);
Mask=[];
for k=1:B
        Mask=[Mask D^(k-1)];
end

%Finding Word Distributions : P(W|t) & P(W)
P=0;
NN=0;
for k=1:size(RAS,2)-B

	%Initializing Conditionl Distribution to Zero - noise distribution
	Pt=zeros(size(NN));

	%Finding Word Distribution conditional t
    n=RAS(:,k:k+B-1)*Mask';
    for l=1:length(n)
        
        index=find(NN==n(l));
        if isempty(index)
			Pt=[Pt 1];
			P=[P 1];
			NN=[NN n(l)];
		else
			Pt(index)=Pt(index)+1;
			P(index)=P(index)+1;
		end
    end

	%Normalized Word Histograms
	PPt=Pt/sum(Pt);
	PP=P/sum(P);

	%Finding Enthropy
	index=find(PPt~=0);
	Ht(k)=sum(PPt(index).*log2(1./PPt(index)));
	index=find(PP~=0);
	H(k)=sum(PP(index).*log2(1./PP(index)));

	%Displaying Output
	if k/100==round(k/100)
		clc
		disp(['Percent Done: ' int2str(k/size(RAS,2)*100) ' %'])
	end

end

%Finding Shuffled Word Distributions : Psh(W|t) & Psh(W)
%This is used to find the shuffled entropy as per Panzeri : Hsh(W|t)
[RASsh]=rastershufflepanzeri(RAS);
P=0;
NN=0;
for k=1:size(RAS,2)-B

	%Initializing Conditionl Distribution to Zero - noise distribution
	Pt=zeros(size(NN));

	%Finding Word Distribution conditional t
    n=RASsh(:,k:k+B-1)*Mask';
    for l=1:length(n)
        
        index=find(NN==n(l));
        if isempty(index)
			Pt=[Pt 1];
			P=[P 1];
			NN=[NN n(l)];
		else
			Pt(index)=Pt(index)+1;
			P(index)=P(index)+1;
		end
    end

	%Normalized Word Histograms
	PPt=Pt/sum(Pt);
	PP=P/sum(P);

	%Finding Enthropy
	index=find(PPt~=0);
	Htsh(k)=sum(PPt(index).*log2(1./PPt(index)));
	index=find(PP~=0);
	Hsh(k)=sum(PP(index).*log2(1./PP(index)));

	%Displaying Output
	if k/100==round(k/100)
		clc
		disp(['Percent Done: ' int2str(k/size(RAS,2)*100) ' %'])
	end

end

%Find the Indepedent Distributions Pind(W|t) and entropy Hind(W|t)
P=0;
NN=0;
Max=max(max(RAS));
for k=1:size(RAS,2)-B

    %Words at time t
    Wt=RAS(:,k:k+B-1);
    
    %Computing Independent Distribution for each t
    HHtind=zeros(1,B);
    for l=1:B
        [Nt]=hist(RAS(:,k+l-1),0:Max);
        Pt=Nt/sum(Nt);
        
        %Finding Enthropy
        index=find(Pt~=0);
        HHtind(l)=sum(Pt(index).*log2(1./Pt(index)));
    end
    
    %Independent Entropy
    Htind(k)=sum(HHtind);
    
	%Displaying Output
	if k/100==round(k/100)
		clc
		disp(['Percent Done: ' int2str(k/size(RAS,2)*100) ' %'])
	end

end


%Mean Spike Rate
Rate=mean(mean(RAS))*Fsd;

%Enthropy per time and per spike
dt=1/Fsd;
InfoData.HWord=H;
InfoData.HWordt=Ht;
InfoData.HSec=H/dt/B;
InfoData.HSect=Ht/dt/B;
InfoData.HSpike=InfoData.HSec/Rate;
InfoData.HSpiket=InfoData.HSect/Rate;

%Shuffled Entropy
InfoData.Hword_sh=Hsh;
InfoData.HWordt_sh=Htsh;
InfoData.HSec_sh=Hsh/dt/B;
InfoData.HSect_sh=Htsh/dt/B;
InfoData.HSpike_sh=InfoData.HSec_sh/Rate;
InfoData.HSpiket_sh=InfoData.HSect_sh/Rate;

%Independent Entropy
InfoData.HWordt_ind=Htind;
InfoData.HSect_ind=Htind/dt/B;
InfoData.HSpiket_ind=InfoData.HSect_ind/Rate;

%Firing Rate
InfoData.Rate=Rate;

%Parameters
InfoData.Param.Fsd=Fsd;
InfoData.Param.dt=1/Fsd;
InfoData.Param.B=B;