%
%function [InfoData]=infwordrasterpanzerisig(RASTER,Fsd,B,sig)
%
%   FILE NAME   : INF WORD RASTER PANZERI SIIG
%   DESCRIPTION : Computes the mutual inforamtion using the shuffling
%                 procedure of Panzeri
%
%                   Ish = H  + - Ht_ind + Ht_sh  - Ht
%
%                 The mutual information is computed at multiple temporal
%                 resolutions by adding uniformaly distributed spike timing
%                 errors of (sig) ms
%
%   RASTER      : Rastergram - compressed format
%   Fsd         : Sampling rate for generating P(W)
%   B           : Length of Word, number of bits
%   sig         : Vector containing added jitter (ms) used to compute
%                 mutual information
%
%RETURNED VARIABLES
%
%   InfoData    : Data Structure containing
%
%                 .IWord_sh      : Shuffled Information per B-bit word at
%                                  Fsd. Computed according to Panzeri as: 
%                               
%                                  Ish = H  + - Ht_ind + Ht_sh  - Ht
%                               
%                 .IWord_bias    : Residual bias computed by Zheng and
%                                  Escabi. Obtained by generating a random
%                                  raster with indentical ISI distribution
%                                  and computing the shuffled Inforamtion
%                                  (Panzeri)
%                 .IWord         : Information per B-bit word at Fsd.
%                                  Obtained as:
%
%                                  IWord = IWord_sh - IWord_bias
%
%                 .IWord_sh_se   : Standard error on IWord_sh
%                 .IWord_bias_se : Standard erro on IWord_bias
%                 .IWord_se      : Standard error on IWord
%                 .IData         : Vector of data structure returned by
%                                  INFWORDRASTERPANZERI
%                 .IData         : Same as IData except for random raster
%                                  with identical ISI distribution
%                 .Rate          : Firing Rate (Hz)
%                 .Param.sig     : Added jitter (ms)
%                 .Param.Fsd     : Sampling Rate (Hz)
%                 .Param.dt      : Temporal resolution (s)
%                 .Param.B       : Number of Bits per Word
%
% (C) Monty A. Escabi, Feb 2020
%
function [InfoData]=infwordrasterpanzerisig(RASTER,Fsd,B,sig,NB)

%Computing Information at Multiple Resoltions
for k=1:length(sig)
    
    %Computing Information at Specified Temporal Resolution
    [RAS]=rasteraddjitterpanzeri(RASTER,sig(k));
    [IData(k)]=infwordrasterpanzeri(RAS,Fsd,B);
    
    %Computing Information for Random Raster at Specified Temporal
    %Resolution - Used to compute residual bias - Zheng and Escabi 2013
    [RASr]=shufflerandraster(RAS);
    [IDatar(k)]=infwordrasterpanzeri(RASr,Fsd,B);
   
end

%Computing Information and Boostrapping Estimates
for k=1:length(sig)
   
    %Computing Information Per Word
    InfoData.IWord_sh(k)=IData(k).HWord(end)-mean(IData(k).HWordt_ind)+mean(IData(k).HWordt_sh)-mean(IData(k).HWordt);
    InfoData.IWord_bias(k)=IDatar(k).HWord(end)-mean(IDatar(k).HWordt_ind)+mean(IDatar(k).HWordt_sh)-mean(IDatar(k).HWordt);
    InfoData.IWord(k)=InfoData.IWord_sh(k)-InfoData.IWord_bias(k);
    
    %Bootstrapping Information Per Word
    %Since essentailly all of the error is in the condition distributions
    %only boostrap the terms containing HWordt
    I_sh_boot=IData(k).HWord(end)-bootstrp(NB,'mean',IData(k).HWordt_ind)+bootstrp(NB,'mean',IData(k).HWordt_sh)-bootstrp(NB,'mean',IData(k).HWordt);
    I_bias_boot=IDatar(k).HWord(end)-bootstrp(NB,'mean',IDatar(k).HWordt_ind)+bootstrp(NB,'mean',IDatar(k).HWordt_sh)-bootstrp(NB,'mean',IDatar(k).HWordt);
    InfoData.IWord_sh_se(k)=std(I_sh_boot);
    InfoData.IWord_bias_se(k)=std(I_bias_boot);
    InfoData.IWord_se(k)=std(I_sh_boot-I_bias_boot);
    
    %Firing Rate
    InfoData.Rate(k)=IData(k).Rate;
    
end

%Information Data Structure
InfoData.IData=IData;
InfoData.IDatar=IDatar;

%Parameters
InfoData.Param.sig=sig;
InfoData.Param.Fsd=Fsd;
InfoData.Param.dt=1/Fsd;
InfoData.Param.B=B;
InfoData.Param.NB=NB;
