%
%function [RASTER]=poissongenstatraster(L,T,Fsd,refractory,N,seed)
%
%       FILE NAME       : POISSON GEN STAT
%       DESCRIPTION     : Stationary Poison Spike Train Generator
%
%       L               : Lambda. Mean spike rate. (spikes/sec)
%   	T               : Spike Train Duration (sec)
%       Fsd             : Sampling Rate for spet
%       refractory      : Refractory period if desired (msec)
%                         Default==0, 'no refractory period'
%                         Must obey: refractory >> 1/lambda
%       N               : Number of trials
%       seed            : Starting seed for random number generator (Optional)
%
%   (C) Monty A. Escabi, Dec. 2020
%
function [RASTER]=poissongenstatraster(L,T,Fsd,refractory,N,seed)

%Input Arguments
if nargin<6
    seed=round(sum(clock*10000));   %Random seed using the clock
end

%Generating Raster
for k=1:N
    RASTER(k).spet=poissongenstat(L,T,Fsd,refractory,seed);
    RASTER(k).Fs=Fsd;
    RASTER(k).T=T;
    seed=seed+1;
end