%
%function [H,Cxx,Cxx_lr,Ryx,U,S,V] = wienermimoreg(X,Y,N,K,L,Cxx)
%	
%	FILE NAME       : WIENER MIMO REG
%	DESCRIPTION 	: Regularized multi input multi output Wiener filter
%
%                       H = Cxx^-1 * Ryx
%
%                     where Cxx is the input covariance matrix, Ryx is the
%                     crosscorrelation matrix between the outputs and
%                     inputs, and H is the multi-input multi-output Wiener
%                     filter matrix. The elements of H (hkl) correspond to
%                     sub-vectors each of which represents the impulse
%                     response between the k-th input and the l-th output.
%
%                     Regularizes by computing a low-rank approximation of
%                     Cxx
%
%   X               : Multi input matrix (Nx1xNx2) - the number of rows
%                     (Nx1) correspond to the number of inputs. Nx2
%                     corresponds to the number of time samples. Can be a
%                     sparse matrix.
%   Y               : Multi output matrix (Ny1xNy2) - the nunmber of rows
%                     (Ny1) corersponds to the number of outputs. Ny2
%                     corresponds to the number of time samples. Typically
%                     Nx2==Ny2. Can be a sparse matrix.
%   N               : Determines the number of impulse response samples.
%                     Half the filter order.
%                     Note that input covariance matrix has 2*N+1 samples
%                     and the impulse response order for each input is
%                     2*N+1
%   K               : Ridge regression parameter (optional, if not included
%                     assumes no ridge regression, k=0)
%   L               : Number of sigular values presserved for low rank
%                     covariance matrix approximation (If L>rank(Cxx) uses
%                     full rank version of Cxx
%   Cxx             : Input covariance matrix (optional) - otherwise it
%                     uses the input X to compute Cxx
%
%RETURNED VARIABLES
%   H               : Multi-input multi-ouput impulse response matrix. The
%                     matrix contains subvectors hkl for each input-ouput
%                     mapping.
%   Cxx             : Input covariance matrix 
%   Cxx_lr          : Low rank input covariance matrix containg L signular
%                     values
%   Ryx             : Output - Input cross correlation function
%
%                     The impulse response is computed as
%
%                          H=pinv(Cxx_lr+K*I)*Ryx;
%
%                     where K is the ridge parameter.
%   U,S,V           : SVD decompostion of Cxx
%
% (C) Mina, Ashley, Monty - 3/4/14 (Edit, 7/18; 11/20, add ridge; MAE)
%
function [H,Cxx,Cxx_lr,Ryx,U,S,V] = wienermimoreg(X,Y,N,K,L,Cxx,Ryx)

%Input Args
if nargin<4
   K=0; 
end
if nargin<5
    L=inf;
end

%Filter order
N=2*N;

%Cross-Covariance Matrix
if ~exist('Cxx')
    for k=1:size(X,1)
        for l=1:size(X,1)
            Ctemp=toeplitz(xcorr(full(X(k,:))-mean(full(X(k,:))),full(X(l,:))-mean(full(X(l,:))),N));
            Cxxtemp=Ctemp(N+1:2*N+1,1:N+1);             
            Cxx((k-1)*(N+1)+1:k*(N+1),(l-1)*(N+1)+1:l*(N+1))=Cxxtemp;
        end
    end
end

%Cross-Correlation Matrix
for k=1:size(X,1)
    for l=1:size(Y,1)
        ryxtemp=xcorr(full(Y(l,:))-mean(full(Y(l,:))),full(X(k,:))-mean(full(X(k,:))),N/2)';    %Added mean removal, MAE, 7/18
        Ryx((k-1)*(N+1)+1:k*(N+1),l)=ryxtemp;
    end
end

%Computing MIMO Wiener filter
I=eye(size(Cxx));
if size(Cxx,1)<L
    L=size(Cxx,1);                  %Full rank
end
[U,S,V] = svds(Cxx,L);
Cxx_lr=U*S*V';                      %L rank approximation of Cxx    
SInv_lr=1./diag(S).*eye(size(S));   %L rank pseudo inverse
CxxInv=V*SInv*U';                   %L rank pseudo inverse approximation for Covariance Matrix - much faster
H(:,:,count)=CxxInv*Ryx;            

%Cxx_lr=U*S*V';                         %L rank approximation of Cxx
%SInv_lr=1./diag(S).*eye(size(S));      %L rank pseudo inverse
%CxxInv=V*SInv*U';                      %L rank pseudo inverse approximation for Covariance Matrix - much faster

% LL=50

% count=1
% for LL=10:10:300
%    
% SS=diag(S);
% SS=SS(1:LL);
% SInv=1./SS.*eye(LL);  %L rank pseudo inverse
% CxxInv=V(:,1:LL)*SInv*U(:,1:LL)';     
% 
% H(:,:,count)=CxxInv*Ryx;
% count=count+1
% 
% end