% Tuning curve functions
