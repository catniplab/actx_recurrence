function []=ntcprep_batch=()
%
%	DESCRIPITION:	Batch file for multiple ntcpreps.
%




ntcprep('lm811148.dtc','c811_t5f13_ch1.mat');
ntcprep('lm811149.dtc','c811_t5f13_ch2.mat');

ntcprep('lm811150.dtc','c811_t5f14_ch1.mat');
ntcprep('lm811151.dtc','c811_t5f14_ch2.mat');





