%
% function []=signalinnoisesoundgen(backdir,foredir,outfile,f1,f2,TW,alpha,df,StdX,T,Tpause,FsRe,SNR,Nrepeats,controlflag,cleanflag)
%
%   FILE NAME               : SIGNAL IN NOISE SOUND GEN
%   DESCRIPTION             : Generates a .RAW and .WAV file which is used
%                             for singal in noise experiments. A control
%                             condition is also delovered which contains
%                             either 1/f spectrum background or matched
%                             spectrumn white noise.
%
%                             The routine generates a WAV file which
%                             contains the summed foreground and
%                             backgrond sounds and is delivered in block
%                             randomize order. 
%
%   backdir                 : Directory containing all background WAV
%                             files
%   foredir                 : Directory containing all foreground WAV
%                             files
%                             used  for the background sound
%   outfile                 : Output file name (No Extension)
%   f1,f2                   : Filter the sound betwen f1 and f2 Hz - typically similar
%                             to f1 and f2 for calibration filter. If f1==0 && f2=Fs/2
%                             then no filter applied.
%   TW                      : Transition width (Hz) for bandpass filter
%   alpha                   : Power law exponent
%   df                      : Spectral Resolution for Periodogram (PSD)
%   StdX                    : Standard deviation of total sound (foreground + background) for playback
%   T                       : Duration of Each Sound (sec). Need to make sure that the
%                             desired duration is < the duration of each WAV File
%   Tpause                  : Pause time (sec) between consecutive
%                             presentations. For these soudns, the
%                             backgrounds are merged by fading in and out
%                             over the Tapuse segment.
%   FsRe                    : Resampling frequency (used only if different
%                             from sound sampling rate)
%   SNR                     : Signal to noise ratio (dB)
%   Nrepeats                : Number of repeats or trials for each sound.
%   controlflag             : Flag used to determine if we use 1/f or
%                             spectrum matched control (-1 to exclude, 0 for phase randomized, or 1 for spectrum equalized)
%   cleanflag               : Flag used to deliver a clean variant of the
%                             foreground sound (1 to include a clean
%                             SNR=inf variant; 0 to exclude)
%
%   NOTE: Requires SOX (Sound eXchange: http://sox.sourceforge.net/)
%
% (C) Monty A. Escabi & Delaina Pedrick, Apr 2019 (Edit Jan 2020, MAE)
%
function []=signalinnoisesoundgen(backdir,foredir,outfile,f1,f2,TW,alpha,df,StdX,T,Tpause,FsRe,SNR,Nrepeats,controlflag,cleanflag)
  
%Close all open files
fclose all;

%Sound List
if ispc
    if backddir(end)~='\'
        backdir=[backdir '\'];
        foredir=[foredir '\'];
    end
else
    if foredir(end)~='/'
        backdir=[backdir '/'];
        foredir=[foredir '/'];
    end
end
ListBack=dir([backdir '*.wav']);
ListFore=dir([foredir '*.wav']);
NB=length(ListBack);                   %Number of background sounds
NF=length(ListFore);                   %Number of foreground sounds

%Generating Bandpass Filter to limit frequency content
Fs=FsRe;
if (f1==0) && (f2==Fs/2)
    H=1;
    Nh=0;
else
    ATT=60;
    H=bandpass(f1,f2,TW,Fs,ATT,'n');
    Nh=(length(H)-1)/2;
end

%Generate Backround Window For Sound
rtb=Tpause*1000;                %Ruse time for merging in ms
dM=rtb*Fs/1000;                 %RT or pause segment duration in sample numbers 
M=ceil((T+2*Tpause)*Fs);        %Windows are added so that they overlap. The pause segment is = to the rt
p=3;
Wb=windowm(Fs,p,M,rtb);

%Generate Foreground Window
rtf=25;               %Foreground Rise Time for merging adjacent sound segments
M=floor(T*Fs);        %Window overlaps the region of the bavkground window with values = 1
p=3;
Wf=windowm(Fs,p,M,rtf);

%Loding Foreground Sound Segments
Gain=10^(-SNR/20);
for k=1:NF
    %Load sounds
    [Y,Fs]=audioread([foredir ListFore(k).name]);
    if Fs ~= FsRe
       Y=resample(Y,FsRe,Fs);
    end
    Y=Y';                       %change to a row vector
    
    %Filtering and truncating to remove edge artifact
    Y=conv(Y,H);
    Y=Y(2*Nh+1:end-2*Nh-1);
    
    %Truncating & Windowing the sounds & normalizing variance
    Y=Y(1:length(Wf)).*Wf;
    Y=Y/std(Y)/sqrt(1+Gain^2)*StdX;

    %Save Foreground sounds
    ForeSound(k).Y=Y;
    ForeSound(k).Fs=FsRe;
    ForeSound(k).FileHeader=ListFore(k).name;
    
end

%Loading Background Sounds and Generetaing variants with 1/f spectrum or
%White noise with matched spectrum if controlflag~=-1
for k=1:NB
    
    %Load T second sound segments
    [Y,Fs]=audioread([backdir ListBack(k).name]);
    if Fs ~= FsRe
       Y=resample(Y,FsRe,Fs);
    end
    Y=Y';                       %change to a row vector
    
    %Control Condition - Spectrum Match or 1/f Sounds
    if controlflag==0
        Ycontrol=randphasespec(Y);
    elseif controlflag==1
        Ycontrol=pre1overf(Y,FsRe,0,FsRe/2,alpha,df);   %Pre 1/f sounds - spectrum matched
    end
      
    %Filtering the original and control background sound and truncating to remove edge artifact
    Y=conv(Y,H);
    Y=Y(2*Nh+1:end-2*Nh-1);
    if controlflag~=-1
        Ycontrol=conv(Ycontrol,H);
        Ycontrol=Ycontrol(2*Nh+1:end-2*Nh-1);
    end
    
    %Truncating & Windowing the sounds & normalizing variance
    Y=Y(1:length(Wb)).*Wb;                                      %Windowing
    Y=Y/std(Y)*Gain/sqrt(1+Gain^2)*StdX;                                                 %Original Background - %Normalizing for appropriate STD
    if controlflag~=-1
        Ycontrol=Ycontrol(1:length(Wb)).*Wb;  
        Ycontrol=Ycontrol/std(Ycontrol)*Gain/sqrt(1+Gain^2)*StdX;
    end
    
    %Save orignal background sounds in sequential order
    BackSound(k).Y=Y;
    BackSound(k).Fs=FsRe;
    BackSound(k).FileHeader=ListBack(k).name;
    BackSound(k).controlflag='Original';
    BackSound(k).cleanflag='N/A';
    
    %Save control background sounds in sequential order
    if controlflag~=-1
        BackSound(k+NB).Y=Ycontrol;
        BackSound(k+NB).Fs=FsRe;
        BackSound(k+NB).FileHeader=ListBack(k).name;
        if controlflag==0
            BackSound(k+NB).controlflag='PhaseRandomized';
            BackSound(k+NB).cleanflag='N/A';
        else
            BackSound(k+NB).controlflag='SpectrumEqualized';
            BackSound(k+NB).cleanflag='N/A';
        end
    end
    
end

%Genrate Clean Variant of Foreground if cleanflag==1
if cleanflag==1
    BackSound(length(BackSound)+1).Y=zeros(1,length(BackSound(1).Y));
    BackSound(end).Fs=FsRe;
    BackSound(end).FileHeader='N/A - zero valued background';
    BackSound(end).controlflag='CleanVariant';
    BackSound(end).cleanflag='CleanVariant';
end

%Randomizing Sound Delivery Order
OrdB=[];
OrdF=[];
order=[];
for k=1:length(BackSound)
    for l=1:NF
            OrdF=[OrdF l];
            OrdB=[OrdB k];
    end
end
rng(0);                                             %Set rarndom number genreator seed
for k=1:Nrepeats
    order=[order randperm(length(OrdF))];           %Radnomized order for first sequences of sounds (e.g., odd sounds); x2 to account for either spectrum matched or 1/f
end
OrderB=OrdB(order);
OrderF=OrdF(order);

%Opening Temporary File
TempFile=[outfile '.s32'];
fidtemp=fopen(TempFile,'wb');
TempFile2=[outfile 'Trig.s32'];
fidtemp2=fopen(TempFile2,'wb');

%Generating Sound Sequence
for k=1:length(OrderB)
    
    %Displaying Progress 
    clc, disp(['Progress: ' int2str(k) ' out of ' int2str(length(order)) ' sound segments generated.'])
    
    %Grabbing current and next sounds
    Xb=BackSound(OrderB(k)).Y;
    Xf=ForeSound(OrderF(k)).Y;
    if k<length(OrderB)
        Xbnext=BackSound(OrderB(k+1)).Y;
    end
    
    %Sound Duration
    T(k)=length(Xf)/Fs;
     
    %Adding adjecent segments during pause period
    if k==1                     %First Segment
        X=[Xb(1:dM) Xb(dM+1:length(Xb)-dM)+Xf  (Xb(length(Xb)-dM+1:end)+Xbnext(1:dM))];
    elseif k==length(OrderB)    %Last Segment
        X=[Xb(dM+1:length(Xb)-dM)+Xf  Xb(length(Xb)-dM+1:end)];
    else
        X=[Xb(dM+1:length(Xb)-dM)+Xf  (Xb(length(Xb)-dM+1:end)+Xbnext(1:dM))];
    end
    
    %Generating Trigger Signal
    Trig=zeros(1,length(X));
    if k==1
        Trig(dM+(1:2000))=floor(2^31*ones(1,2000)-1);
    else
        Trig(1:2000)=floor(2^31*ones(1,2000)-1);
    end
    
    %Writing to File 
	%Maximum Observed experimental Max=abs(X) was ~ 6
	%Normalized so the 2^27*6<2^27*10<2^31
	%This Guarantees No Clipping
    clear Y
	Y(1:2:2*length(X))=round(X*2^31);
    Y(2:2:2*length(X))=round(X*2^31);
	fwrite(fidtemp,Y,'int32');
    fwrite(fidtemp2,Trig,'int32');
end

%Adding Parameters to Data Structure
Param.f1=f1;
Param.f2=f2;
Param.TW=TW;
Param.alpha=alpha;
Param.df=df;
Param.StdX=StdX;
Param.T=T;
Param.Tpause=Tpause;
Param.FsRe=FsRe;
Param.SNR=SNR;
Param.Nrepeats=Nrepeats;
Param.controlflag=controlflag;
Param.cleanflag=cleanflag;
Param.OrderB=OrderB;
Param.OrderF=OrderF;
LF=char(10);
Param.Note=['The order parameter is structured as follows: ' LF LF '1) There are NF foreground sounds stored sequentially in the data structure ''ForeSound''.' LF LF, ...
    '2) There are NB background sounds used. For each background, there are two conditions: ' LF , ...
    '   the ''Original'' and the ''Control'' which is selected from either a spectrum matched condition or 1/f matched spectrum.' LF LF, ...
    '3) Ordering is determined by OrderF and OrderB. For the k-th sounds, the Foreground and Background can be deciphered using:' LF LF, ...
    '   BackSound(Param.OrderB(k)) & ForeSound(Param.OrderF(k))' LF LF, ...
    '4) The SNR is applied so that the total variance (foreground + background) is constant (fixed at StdX^2)' LF LF, ...
    '5) Param(k).SoundBack, Param(k).SoundFore, and Param(k).ControlFlag contains the fileheaders for the background and' LF, ...
    '   foreground along with the flag for the control condition (Original, Spectrum Match, or 1/f)', ...
    ];
    
%Saving Paramters
f=['save ' outfile '_Param.mat  Param BackSound ForeSound'];
eval(f)

%Closing all files
fclose all;

%Using SOX to convert to WAV File
f=['!sox -r ' int2str(Fs) ' -c 2 ' TempFile ' -b 32 -e floating-point ' outfile '.wav'];
eval(f);
f=['!sox -r ' int2str(Fs) ' -c 1 ' TempFile2 ' -b 32 -e floating-point ' outfile '_Trig.wav'];
eval(f);
   