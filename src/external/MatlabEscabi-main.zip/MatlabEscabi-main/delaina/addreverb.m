%
%function [X,H,Hd,Hr] = addreverb(X,Fs,t60,N,DR)
%	
%	FILE NAME       : ADD REVERV
%	DESCRIPTION 	: Adds synthetic reverb. The reverb model consists of N
%                     random delayed reflections where the amplitude of the
%                     reflection decays exponentially with a t60
%                     reverberation time constant. The reverb is choosen
%                     for a specific direct to reverberant ratio (DR).
%
%   X               : Input sound vector
%   Fs              : Sampling rate
%   t60             : T-60 time (msec)
%   N               : Number of random reflections
%   DR              : Direct to reverberant ratio (dB), defined as
%                   
%                     DR=10*log10(var(Xd) / var(Xr) )
%
%                     where Xd is the direct sound and Xr is the
%                     reverberant sound field
%
%RETURNED VALUES
%
%   Xr              : Reverberant sound vector
%   H               : Total impulse response
%   Hd              : Direct sound impulse response
%   Hr              : Reverberant sound field impulse response
%
% (C) Monty A. Escabi / Delaina Pedric, Jan 2020
%
function [Xr,H,Hd,Hr]=addreverb(X,Fs,t60,N,DR)

%Generate Reverberant Impulse Response
tau=-t60/1000/log(0.001);
M=ceil(t60/1000*2*Fs);
time=(0:M)/Fs;

%Reverberant Field
Hr=zeros(size(time));
i=floor(rand(1,N)*M)+1;
Hr(i)=ones(size(i));
Hr=Hr.*exp(-time/tau);          %Reverberant Impulse Response
Hr=(Hr./sqrt(sum(Hr.^2)));      %Constant Power
Hr=Hr*10.^(-DR/20);             %Impose DR

%Direct Field
Hd=zeros(size(time));
Hd(1)=1;                        %Direct Impulse Response - power = 1

%Total Impulse Response
H=Hd+Hr;

%Generating Reverberant Sound
Xr=conv(X,H);                   %Convolves the original sound with the reverb field
