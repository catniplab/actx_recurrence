%
%function [LNPNetRAS]=glnpaudnetwork(GModel,X,Fs,Fsd,nlparam,Tref)
%
%   FILE NAME       : G LNP AUD NETWORK
%   DESCRIPTION     : Gabor Linear-Nonlinear-Poisson Auditory Network
%                     Model used by Khatami and Escabi PLOS Comp Bio 2020
%
%   GModel          : Vector of data structures containing the gabor fitted
%                     STRF for each channel of the network. Obtained using
%                     GABORMODELFIT.m
%   X               : If X is a vector then it corresponds to the input
%                     sound waveform. Otherwise, if X is a data structure
%                     then it represents the output of COCHLEOGRAM.m
%   Fs              : Sampling rate for the input waveform (Hz)
%   Fsd             : Sampling rate for the output spike train (Hz)
%   nlparam         : Vector that determines the type of linearity /
%                     nonlinearity. If nlparam is a 2 element vector then
%                     then a linear I/O relation is assumed and
%                     nlparam=[Lambda0 G]. If nlparam is a scalar then use
%                     a rectifying NL and nlparam=G
%   Tref            : Refractory Period (ms) (Default == 1 ms)
%
%OUTPUT VARIABLES
%
%   LNPNetRAS       : Data structure containing the oupout spike trains.
%                     Stored as a dot-raster where trials correspond to the 
%                     network channels.
%
% (C) Monty A. Escabi, Feb 2017 (Edit Nov 2019)
%
function [LNPNetRAS]=glnpaudnetwork(GModel,X,Fs,Fsd,nlparam,Tref)

%Inpout Arguments
if nargin<6 | ~exist('Tref')
        Tref=1;
end

%Normalizing Cochleogram for zero mean - generating if necessary
if isstruct(X)
    CochData=X;
    SdB=CochData.SdB;
    SdB=SdB-mean(mean(SdB));
else
    %Compute Cochleogram
    dX=1/10;
    f1=100;
    fN=Fs/2;
    Fm=750;
    OF=2;
    Norm='Amp';
    dis='n';
    ATT=60;
    FilterType='GammaTone';
    BWType='cb';
    [CochData]=cochleogram(X,Fs,dX,f1,fN,Fm,OF,Norm,dis,ATT,FilterType,BWType);
    SdB=CochData.SdB;
    SdB=SdB-mean(mean(SdB));
end

%Convolving STRFs and Generating Output
for k=1:length(GModel)

    %Generating Model STRF
    input.X=log2(CochData.faxis/GModel(k).faxis(1));    %Reference the octave frequency on the original frequency used to genrate the model
    input.taxis=CochData.taxis(1:125)*1000;             %Time axis in ms
    [STRFm]=strfgabor1(GModel(k).beta1,input);          %Generate Model STRF for the kth channel 
    
    %Convolving STRF and generating k-th output
    for m=1:size(SdB,1)
        Ym(m,:)=conv(SdB(m,:),STRFm(m,:));      %Convolve each channel
    end
    Y(k,:)=sum(Ym,1);                           %Sum across frequency channels

end
Y=Y-mean(mean(Y));                              %Normalize output for zero Mean and unit variance
Y=Y/std(reshape(Y,1,[]));

%Rectifying Nonlinaerity or Linear I/O
if length(nlparam)==1
    G=nlparam(1);
    Y=G*max(Y,0);
else
    Lambda0=nlparam(1);
    G=nlparam(2);
    Y=Lambda0 + G * Y;
    
    if min(min(Y))<0
        disp(['Warning, Minimum target firing rate is < 0 : Min = ' num2str(min(min(Y)),5)  ' Max = ' num2str(max(max(Y)),5) ])
    end
end

%Passing time-varying output to Poisson generator
for k=1:length(GModel)
    Fs=1/CochData.taxis(2);                                                 %Cochleogram sampling rate
    [LNPNetRAS(k).spet]=poissongen(Y(k,:),Fs,Fsd,Tref);                     %Poisson spike train generator
    LNPNetRAS(k).Fs=Fsd;
    LNPNetRAS(k).T=size(Y,2)/Fs;
end